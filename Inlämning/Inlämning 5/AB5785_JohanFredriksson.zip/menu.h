//Johan Fredriksson AB5785.
#pragma once

//main.c only need access to one function, increases isolation.
void drawMenu();