#ifndef THROWDICE_H
#define THROWDICE_H

void castDice(double numbOfCast);
void drawDiceMenu();
void handleDiceInput();
void drawDiceResult(double numbOfCast);
double dicePercent(double side, double numbOfCast);

#endif //!THROWDICE_H