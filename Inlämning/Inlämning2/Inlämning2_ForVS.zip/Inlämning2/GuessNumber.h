#ifndef GUESSNUMBER_H
#define GUESSNUMBER_H

void guessNumb(void);
int generateRndNum();
void drawGuessMenu(void);
void handleGuessInput(void);

#endif //!GUESSNUMBER_H