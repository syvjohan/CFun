#include "Random.h"

int generateRndNum(int maxSize) 
{
	return rand() % maxSize + 1;
}
