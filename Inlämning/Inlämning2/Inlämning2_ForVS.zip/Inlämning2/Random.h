#ifndef RANDOM_H
#define RANDOM_H

#include "Defs.h"

int generateRndNum(int maxSize);
	
#endif //!RANDOM_H