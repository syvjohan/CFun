#ifndef INPUTVALIDATION_H
#define INPUTVALIDATION_H

int validateNumber(int *outInt);
int validateUINTMAX(int number);
int validateMin(int number);
#endif //!INPUTVALIDATION_H