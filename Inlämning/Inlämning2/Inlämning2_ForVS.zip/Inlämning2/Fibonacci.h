#ifndef FIBONACCI_H
#define FIBONACCI_H

void drawFibMenu();
void drawFibResult();
void handleFibInput();
void calculateFib(int maxNumber);

#endif //!FIBONACCI_H